Mystery Inc. Case File: The Haunting of the Web Server

Clue Analysis:
- Shaggy and Scooby checked the page in a browser and just found a regular, boring wall.
- Jinkies! One specific visitor managed to trigger a hidden trapdoor and got a totally different response from the exact same URL.
- Edge logs, header captures, and app events all leave the same glowing footprints (Request IDs).
- Put on your detective ascot and rebuild that exact visit. There's no need to go poking the site (NO SCANNING).
